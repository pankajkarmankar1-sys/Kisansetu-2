import { Html, Head, Main, NextScript } from "next/document";
export default function Document() {
  return (
    <Html lang="hi">
      <Head>
        <meta charSet="utf-8" />
        <link rel="icon" href="/favicon.svg" />
      </Head>
      <body>
        <Main />
        <NextScript />
      </body>
    </Html>
  );
}
